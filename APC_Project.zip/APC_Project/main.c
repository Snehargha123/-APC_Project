#include "apc.h"

int _CRT_glob = 0;

int main(int argc, char *argv[])
{

    /* Declare the pointers */
    Dlist *head1 = NULL, *tail1 = NULL;
    Dlist *head2 = NULL, *tail2 = NULL;
    Dlist *headR = NULL, *tailR = NULL;

    int flag = 0;

    if (argc != 4)
    {
        printf("Usage: ./a.out <operand1> <operator> <operand2>\n");
        return FAILURE;
    }

    /* Convert operands into linked lists */

    digit_to_list(&head1, &tail1, &head2, &tail2, argv);


    if (head1 == NULL || head2 == NULL)
    {
        printf("Invalid operand\n");
        return FAILURE;
    }


    char operator = argv[2][0];

    switch (operator)
    {
        case '+':

            addition(&head1, &tail1, &head2, &tail2, &headR, &tailR);

            print_list(headR);

            break;


        case '-':

        {
            int ret;

            ret = list_compare(head1, head2, tail1, tail2);

            if (ret == 1)
            {
                /* list1 > list2 */

                subtraction(&head1, &tail1, &head2, &tail2, &headR, &tailR);
            }
          
            else if (ret == 0)
            {
                /* list1 < list2 */

                subtraction(&head2, &tail2, &head1, &tail1, &headR, &tailR);

                flag = 1;
            }

            else
            {
                /* list1 == list2 */

                printf("0\n");
                break;
            }

            if (flag == 1 && headR != NULL)
                {
                    headR->data = headR->data * (-1);

                }

                print_list(headR);

            break;
        }


        case '*':

            multiplication(&head1, &tail1, &head2, &tail2, &headR, &tailR);

            if (addition(&head1, &tail1,  &head2, &tail2, &headR, &tailR) == FAILURE)
             {
               printf("Addition failed\n");
                return FAILURE;
             }

            print_list(headR);
            break;


        case '/':

            division(&head1, &tail1, &head2, &tail2, &headR, &tailR);

            print_list(headR);

            break;


        default:

            printf("Invalid Input:-( Try again...\n");
            break;
    }

    delete_list(&head1, &tail1);
    delete_list(&head2, &tail2);
    delete_list(&headR, &tailR);

    return SUCCESS;
}


