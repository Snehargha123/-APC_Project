#include "apc.h"

int multiplication(Dlist **head1, Dlist **tail1,
                   Dlist **head2, Dlist **tail2,
                   Dlist **headR, Dlist **tailR)
{
    Dlist *temp1;
    Dlist *temp2;


    Dlist *headR1 = NULL;
    Dlist *tailR1 = NULL;

    Dlist *headR2 = NULL;
    Dlist *tailR2 = NULL;

    int carry;
    int result;
    int zero_count = 0;


    *headR = NULL;
    *tailR = NULL;

   
    if (head1 == NULL || *head1 == NULL ||
        head2 == NULL || *head2 == NULL)
    {
        return FAILURE;
    }

  
    if ((*head1)->data == 0 && (*head1)->next == NULL)
    {
        insert_at_last(headR, tailR, 0);
        return SUCCESS;
    }


    if ((*head2)->data == 0 && (*head2)->next == NULL)
    {
        insert_at_last(headR, tailR, 0);
        return SUCCESS;
    }

   
    temp2 = *tail2;

    while (temp2 != NULL)
    {
       
        temp1 = *tail1;

        carry = 0;

     
        while (temp1 != NULL)
        {
            result = (temp1->data * temp2->data) + carry;

          
            insert_at_first(&headR2,
                            &tailR2,
                            result % 10);

         
            carry = result / 10;

         
            temp1 = temp1->prev;
        }

      
        if (carry != 0)
        {
            insert_at_first(&headR2,
                            &tailR2,
                            carry);
        }

      
        for (int i = 0; i < zero_count; i++)
        {
            insert_at_last(&headR2,
                           &tailR2,
                           0);
        }

      
        if (headR1 == NULL)
        {
            headR1 = headR2;
            tailR1 = tailR2;

            headR2 = NULL;
            tailR2 = NULL;
        }
        else
        {
            if (addition(&headR1, &tailR1,
                         &headR2, &tailR2,
                         headR, tailR) == FAILURE)
            {
                return FAILURE;
            }

    
            delete_list(&headR1, &tailR1);
            delete_list(&headR2, &tailR2);

         
            headR1 = *headR;
            tailR1 = *tailR;

            *headR = NULL;
            *tailR = NULL;
        }

        temp2 = temp2->prev;

        zero_count++;
    }


    *headR = headR1;
    *tailR = tailR1;

    return SUCCESS;
}