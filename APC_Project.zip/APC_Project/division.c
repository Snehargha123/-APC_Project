#include "apc.h"


int division(Dlist **head1, Dlist **tail1,
             Dlist **head2, Dlist **tail2,
             Dlist **headR, Dlist **tailR)
{
    int count = 0;

    /* Check division by zero */
    if (head2 == NULL || *head2 == NULL)
    {
        printf("Error: Division by zero\n");
        return FAILURE;
    }

    /* Divisor should not be 0 */
    if ((*head2)->data == 0 && (*head2)->next == NULL)
    {
        printf("Error: Division by zero\n");
        return FAILURE;
    }

    /* Initially result/remainder list should be empty */
    *headR = NULL;
    *tailR = NULL;

    /*
     * Repeated subtraction
     *
     * Example:
     * 123 / 3
     *
     * 123 - 3 = 120   count = 1
     * 120 - 3 = 117   count = 2
     * ...
     *   6 - 3 = 3     count = 40
     *   3 - 3 = 0     count = 41
     */
    while (*head1 != NULL &&
           list_compare(*head1, *head2, *tail1, *tail2) >= 0)
    {
        /* Clear temporary result */
        *headR = NULL;
        *tailR = NULL;

        /*
         * headR/tailR will contain:
         *
         * dividend - divisor
         */
        if (subtraction(head1, tail1,
                        head2, tail2,
                        headR, tailR) == FAILURE)
        {
            return FAILURE;
        }

        /*
         * Delete old dividend
         */
        delete_list(head1, tail1);

        /*
         * New dividend = subtraction result
         */
        *head1 = *headR;
        *tail1 = *tailR;

        /*
         * Detach result pointers.
         * The list itself is NOT deleted.
         */
        *headR = NULL;
        *tailR = NULL;

        count++;
    }

    /*
     * head1/tail1 now contain the remainder.
     */
    *headR = *head1;
    *tailR = *tail1;

    /*
     * Important:
     * Detach head1/tail1 because headR/tailR
     * are now pointing to the same list.
     */
    *head1 = NULL;
    *tail1 = NULL;

    /*
     * Store quotient.
     *
     * If your main() expects quotient through
     * headR/tailR, then this approach cannot be used
     * because headR/tailR currently contain remainder.
     */

    printf("Quotient = %d\n", count);

    return SUCCESS;
}