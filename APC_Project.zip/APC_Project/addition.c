#include "apc.h"

int addition(Dlist **head1, Dlist **tail1,
             Dlist **head2, Dlist **tail2,
             Dlist **headR, Dlist **tailR)
{
    Dlist *temp1 = *tail1;
    Dlist *temp2 = *tail2;

    int result;
    int carry = 0;

    /* Initialize result list */
    *headR = NULL;
    *tailR = NULL;

    while (temp1 != NULL || temp2 != NULL)
    {
        if (temp1 != NULL && temp2 != NULL)
        {
            result = temp1->data + temp2->data + carry;

            insert_at_first(headR, tailR, result % 10);

            carry = result / 10;

            temp1 = temp1->prev;
            temp2 = temp2->prev;
        }
        else if (temp1 != NULL)
        {
            result = temp1->data + carry;

            insert_at_first(headR, tailR, result % 10);

            carry = result / 10;

            temp1 = temp1->prev;
        }
        else
        {
            result = temp2->data + carry;

            insert_at_first(headR, tailR, result % 10);

            carry = result / 10;

            temp2 = temp2->prev;
        }
    }

    /* Final carry */
    if (carry != 0)
    {
        insert_at_first(headR, tailR, carry);
    }

    return SUCCESS;
}