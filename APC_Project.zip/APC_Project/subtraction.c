#include "apc.h"

int subtraction(Dlist **head1, Dlist **tail1,
                Dlist **head2, Dlist **tail2,
                Dlist **headR, Dlist **tailR)
{
    Dlist *temp1 = *tail1;
    Dlist *temp2 = *tail2;

    int borrow = 0;
    int diff;

    while (temp1 != NULL)
    {
        diff = temp1->data - borrow;

        if (temp2 != NULL)
        {
            diff = diff - temp2->data;
            temp2 = temp2->prev;
        }

        if (diff < 0)
        {
            diff = diff + 10;
            borrow = 1;
        }
        else
        {
            borrow = 0;
        }

        insert_at_first(headR, tailR, diff);

        temp1 = temp1->prev;
    }

    /* Remove leading zeroes */
    while (*headR != NULL &&
           (*headR)->data == 0 &&
           (*headR)->next != NULL)
    {
        Dlist *temp = *headR;

        *headR = (*headR)->next;
        (*headR)->prev = NULL;

        free(temp);
    }

    return SUCCESS;
}



int list_compare(Dlist *head1, Dlist *head2,
                 Dlist *tail1, Dlist *tail2)
{
    Dlist *temp1 = head1;
    Dlist *temp2 = head2;

    int list1_count = 0;
    int list2_count = 0;

    /* Count nodes of list1 */
    while (temp1 != NULL)
    {
        list1_count++;
        temp1 = temp1->next;
    }

    /* Count nodes of list2 */
    while (temp2 != NULL)
    {
        list2_count++;
        temp2 = temp2->next;
    }

    /* Compare number of digits */
    if (list1_count > list2_count)
    {
        return 1;
    }
    else if (list1_count < list2_count)
    {
        return -1;
    }

    /* Same number of digits */
    temp1 = head1;
    temp2 = head2;

    /* Compare digit by digit */
    while (temp1 != NULL && temp2 != NULL)
    {
        if (temp1->data > temp2->data)
        {
            return 1;
        }
        else if (temp1->data < temp2->data)
        {
            return -1;
        }

        temp1 = temp1->next;
        temp2 = temp2->next;
    }

    /* Both lists are equal */
    return 0;
}